package com.example.todolist;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateActivity extends AppCompatActivity {

    EditText category_input, subcategory_input, priority_input;
    Button update_button;

    String id, category, subcategory, priority;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update);

        category_input = findViewById(R.id.category_input2);
        subcategory_input = findViewById(R.id.subcategory_input2);
        priority_input = findViewById(R.id.priority_input2);
        //
        getAndSetIntentData();

        update_button.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(UpdateActivity.this);
                myDB.updateData(id, category, subcategory, priority);
            }
        });
    }

    void getAndSetIntentData() {
        if ( getIntent().hasExtra("id") && getIntent().hasExtra("category") &&
            getIntent().hasExtra("subcategory") && getIntent().hasExtra("priority") ) {
                // Getting Data from Intent
                id = getIntent().getStringExtra("id");
                category = getIntent().getStringExtra("category");
                subcategory = getIntent().getStringExtra("subcategory");
                priority = getIntent().getStringExtra("priority");

                category_input.setText(category);
                subcategory_input.setText(subcategory);
                priority_input.setText(priority);
        } else {
            Toast.makeText(this, "No data.", Toast.LENGTH_SHORT).show();
        }
    }
}
