package com.example.todolist;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.text.Layout;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    Activity activity;
    private Context context;
    private ArrayList task_id, task_category, task_subcategory, task_priority;

    int position;

    CustomAdapter(MainActivity mainActivity, Activity activity, ArrayList task_id, ArrayList task_category, ArrayList task_subcategory,
                  ArrayList task_priority) {
        this.activity = activity;
        this.context = context;
        this.task_id = task_id;
        this.task_category = task_category;
        this.task_subcategory = task_subcategory;
        this.task_priority = task_priority;

    }
    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, final int position) {
        this.position = position;

        holder.task_id_txt.setText(String.valueOf(task_id.get(position)));
        holder.task_category_txt.setText(String.valueOf(task_category.get(position)));
        holder.task_subcategory_txt.setText(String.valueOf(task_subcategory.get(position)));
        holder.task_priority_txt.setText(String.valueOf(task_priority.get(position)));
        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UpdateActivity.class);
                intent.putExtra("id", String.valueOf(task_id.get(position)));
                intent.putExtra("category", String.valueOf(task_category.get(position)));
                intent.putExtra("subcategory", String.valueOf(task_subcategory.get(position)));
                intent.putExtra("priority", String.valueOf(task_priority.get(position)));
                activity.startActivityForResult(intent, 1);
             }
        });
    }

    @Override
    public int getItemCount() {
        return task_id.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{

        TextView task_id_txt, task_category_txt, task_subcategory_txt, task_priority_txt;
        LinearLayout mainLayout;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            task_id_txt = itemView.findViewById(R.id.task_id_txt);
            task_category_txt = itemView.findViewById(R.id.task_category_txt);
            task_subcategory_txt = itemView.findViewById(R.id.task_subcategory_txt);
            task_priority_txt = itemView.findViewById(R.id.task_priority_txt);
            mainLayout = itemView.findViewById(R.id.mainLayout);
         }
    }
}
